%%%data from the model of Martian ionospheric irregularities
clear all;
close all;
load('Mars_iono_windshears.mat');

%%%%Figure 0 initial profiles for co2 and o2+
%%%%Ne or ion O2+
figure;
subplot(1,2,1);
deltH=0.2;
z=120:deltH:200;
ne=Mars_iono_windshears.Ne0_profile;
plot((ne),z,'linewidth',2); hold on;
ylabel('Altitude (km)','FontSize',14,'fontweight','bold');
xlabel('O_2^+ density (m^-^3)','FontSize',14,'fontweight','bold');
set(gca,'FontWeight','bold','FontSize',14);
grid on;
title('Plasma density');
%%%nn CO2
subplot(1,2,2);
deltH=0.2;
z=120:deltH:200;
nn=Mars_iono_windshears.nnCO2_profile;
plot((nn),z,'linewidth',2); hold on;
ylabel('Altitude (km)','FontSize',14,'fontweight','bold');
xlabel('CO_2 density (m^-^3)','FontSize',14,'fontweight','bold');
set(gca,'FontWeight','bold','FontSize',14);
grid on;
title('CO2 density');


%%Figure 1 Ne
nx=Mars_iono_windshears.nx; 
ny=Mars_iono_windshears.ny;
dx=Mars_iono_windshears.dx;
dy=Mars_iono_windshears.dy;
hbase=Mars_iono_windshears.hbase;
cMax=10.1;%logN
cMin=9.6;
figure; 
figindex=1;

figtime=Mars_iono_windshears.rt;
clevel=[0.03  0.03  0.01 0.01 0.01 0.01];
for i=1:length(figtime)
    
    subplot(2,3,figindex);
    phy_tmp1=reshape(Mars_iono_windshears.Ne(figindex,:,:),ny,nx);
    contourf((0:nx-1)*dx,hbase+(0:ny-1)*dy,log10(exp(phy_tmp1)), 'LevelStep',clevel(figindex)); %'Lines','none'
    caxis([cMin cMax]);
    colormap('jet');
    if figindex==1 || figindex==4 || figindex==7
        ylabel('Altitude (km)','FontSize',14,'fontweight','bold');
    end
    if figindex==4 || figindex==5 || figindex==6
        xlabel('Zonal distance (km)','FontSize',14,'fontweight','bold');
    end
    set(gca,'FontWeight','bold','FontSize',14);
    stitle=sprintf('t=%d s',figtime(i));
    title(stitle);
    figindex=figindex+1;
    disp(i);
end


%%%Figure 2 magnetic field
figure; 
figindex=1;
figtime=Mars_iono_windshears.rt;
clevel=[0.05  0.25 0.25  0.25 0.25 0.25];

for i=1:length(figtime)

    subplot(2,3,figindex);
    phy_tmp1=reshape(Mars_iono_windshears.B(figindex,:,:),ny,nx);
    contourf((0:nx-1)*dx,hbase+(0:ny-1)*dy,(phy_tmp1)./1e-9, 'LevelStep',clevel(figindex));% , 'Lines','none'
%     caxis([14 16]);
    caxis([18 23]);
    colormap('jet');
    if figindex==1 || figindex==4 || figindex==7
        ylabel('Altitude (km)','FontSize',14,'fontweight','bold');
    end
    if figindex==4 || figindex==5 || figindex==6
        xlabel('Zonal distance (km)','FontSize',14,'fontweight','bold');
    end
    set(gca,'FontWeight','bold','FontSize',14);
    stitle=sprintf('t=%d s',figtime(i));
    title(stitle);
    figindex=figindex+1;
    disp(i);
end


%%%%%%%%Figure 3 O2+ density profiles

cMax=9.5;%logN
cMin=8.5;
%%%density-altitude
dis=[40];
figure; 
figindex=1;
figtime=Mars_iono_windshears.rt;
linec={'r','b','g'};
for i=5:length(figtime)


    phy_tmp1=reshape(Mars_iono_windshears.Ne(i,:,:),ny,nx);
    phy_tmp1=exp(phy_tmp1)./1e6;
   subplot(1,2,1);

    dispos=(dis)./dx+1;
    plot(phy_tmp1(:,dispos),hbase+(0:ny-1)*dy,cell2mat(linec(figindex)),'linewidth',2); hold on;
    
    ylabel('Altitude (km)','FontSize',14,'fontweight','bold');
    %end
    %if figindex==7 || figindex==8 || figindex==9
        xlabel('Ne (cm^-^3)','FontSize',14,'fontweight','bold');
   % end
    set(gca,'FontWeight','bold','FontSize',14);
    stitle=sprintf('Plasma density');
    title(stitle);
%     axis([2000 3200 130 170]);
    grid on;
    legend({'700s','1000s'},'FontSize',12);
    figindex=figindex+1;
    disp(i);
end


%%%Figure 3 magnetic field profile
% figure; 
figindex=1;
figtime=Mars_iono_windshears.rt;
clevel=[0.01 0.25 0.25 0.25 0.25 0.25 0.25 0.25 0.25];

for i=5:length(figtime)

    phy_tmp1=reshape(Mars_iono_windshears.B(i,:,:),ny,nx);
    phy_tmp1=phy_tmp1./1e-9;%nT
    
    dispos=(dis)./dx+1;
    subplot(1,2,2);
    plot(phy_tmp1(:,dispos),hbase+(0:ny-1)*dy,cell2mat(linec(figindex)),'linewidth',2); hold on;
    
    ylabel('Altitude (km)','FontSize',14,'fontweight','bold');

    xlabel('|B| (nT)','FontSize',14,'fontweight','bold');
    set(gca,'FontWeight','bold','FontSize',14);
    stitle=sprintf('Magnetic field');
    title(stitle);
%     axis([8 11 130 170]);
    grid on;
    legend({'700s','1000s'},'FontSize',12);
    figindex=figindex+1;
    disp(i);

end




